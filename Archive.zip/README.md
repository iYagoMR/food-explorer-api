Food explorer is a simple DoorDash-like app that i developed for my portfolio.

The front end is fully built using reactjs while the backend api was built on nodejs

This is the api repository but you can check the front end here -> https://github.com/iYagoMR/food-explorer-front
